## Consigna 1
task_one = 10 + 3
print(float(task_one))


## Consigna 2
task_two = 10/3
print(int(task_two))

## Consigna 3
task_three = 5*2
print(float(task_three))