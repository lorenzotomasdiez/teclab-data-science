message = "Menú del día: Hamburguesas."
print(message)

'''
### Respuesta:
Los pasos a seguir que se debieron seguir desde la apertura del IDE, hasta ver el texto en pantalla son los siguientes:
- Crear carpeta de trabajo.
- Abrir el IDE.
- Abrir carpeta de trabajo.
- Crear un archivo con extensión .py.
- Crear la variable que va a contener el mensaje.
- Asignar el valor a la variable con el contenido string de "Menú del día: Hamburguesas".
- Imprimir la variable en pantalla utilizando la funcion print y referenciando la variable creada.
'''